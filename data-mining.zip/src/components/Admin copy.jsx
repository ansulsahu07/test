import React, { useState } from "react";
import { Button, Col, Container, Form, Modal, Row, Table } from "react-bootstrap";

function Admin() {
    const [wacHistoryData, setWacHistoryData] = useState([
        { id: 1, brand: "Brand A", productId: "PROD001", period: "Q1 2025", wac: 120.5, effectiveStartDate: "2025-01-01", effectiveEndDate: "2025-03-31" },
        { id: 2, brand: "Brand B", productId: "PROD002", period: "Q2 2025", wac: 130.75, effectiveStartDate: "2025-04-01", effectiveEndDate: "2025-06-30" },
        { id: 3, brand: "Brand C", productId: "PROD003", period: "Q3 2025", wac: 125.0, effectiveStartDate: "2025-07-01", effectiveEndDate: "2025-09-30" }
    ]);

    const [demandUnitData, setDemandUnitData] = useState([
        { id: 1, brand: "Brand A", period: "Q1 2025", productId: "PROD001", demandUnitValue: 1500, effectiveStartDate: "2025-01-01", effectiveEndDate: "2025-03-31" },
        { id: 2, brand: "Brand B", period: "Q2 2025", productId: "PROD002", demandUnitValue: 1800, effectiveStartDate: "2025-04-01", effectiveEndDate: "2025-06-30" },
        { id: 3, brand: "Brand C", period: "Q3 2025", productId: "PROD003", demandUnitValue: 2000, effectiveStartDate: "2025-07-01", effectiveEndDate: "2025-09-30" }
    ]);

    const [showModal, setShowModal] = useState(false);
    const [selectedRow, setSelectedRow] = useState(null);
    const [editType, setEditType] = useState(""); // "wac" or "demand"

    const [addingNewWac, setAddingNewWac] = useState(false);
    const [newWacRow, setNewWacRow] = useState({
        brand: "", productId: "", period: "", wac: "", effectiveStartDate: "", effectiveEndDate: ""
    });

    const [addingNewDemand, setAddingNewDemand] = useState(false);
    const [newDemandRow, setNewDemandRow] = useState({
        brand: "", productId: "", period: "", demandUnitValue: "", effectiveStartDate: "", effectiveEndDate: ""
    });

    const handleEditClick = (item, type) => {
        setSelectedRow({ ...item });
        setEditType(type);
        setShowModal(true);
    };

    const handleCloseModal = () => {
        setShowModal(false);
        setSelectedRow(null);
        setEditType("");
    };

    const handleSave = () => {
        if (editType === "wac") {
            setWacHistoryData(prev => prev.map(row => row.id === selectedRow.id ? selectedRow : row));
        } else {
            setDemandUnitData(prev => prev.map(row => row.id === selectedRow.id ? selectedRow : row));
        }
        handleCloseModal();
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setSelectedRow(prev => ({
            ...prev,
            [name]: name === "wac" || name === "demandUnitValue" ? parseFloat(value) : value
        }));
    };

    const handleNewWacChange = (e) => {
        const { name, value } = e.target;
        setNewWacRow(prev => ({
            ...prev,
            [name]: name === "wac" ? parseFloat(value) : value
        }));
    };

    const handleNewDemandChange = (e) => {
        const { name, value } = e.target;
        setNewDemandRow(prev => ({
            ...prev,
            [name]: name === "demandUnitValue" ? parseFloat(value) : value
        }));
    };

    const handleNewWacSave = () => {
        const newEntry = { ...newWacRow, id: wacHistoryData.length + 1 };
        setWacHistoryData(prev => [...prev, newEntry]);
        setNewWacRow({ brand: "", productId: "", period: "", wac: "", effectiveStartDate: "", effectiveEndDate: "" });
        setAddingNewWac(false);
    };

    const handleNewDemandSave = () => {
        const newEntry = { ...newDemandRow, id: demandUnitData.length + 1 };
        setDemandUnitData(prev => [...prev, newEntry]);
        setNewDemandRow({ brand: "", productId: "", period: "", demandUnitValue: "", effectiveStartDate: "", effectiveEndDate: "" });
        setAddingNewDemand(false);
    };

    return (
        <Container>
            {/* WAC History Table */}
            <Row className="align-items-center mb-2">
                <Col><h5>WAC History Table</h5></Col>
                <Col className="text-end">
                    <Button variant="success" size="sm" onClick={() => setAddingNewWac(true)}>Add</Button>
                </Col>
            </Row>
            <Row>
                <Col>
                    <Table striped bordered responsive className="text-center">
                        <thead>
                            <tr>
                                <th>Brand</th><th>Product ID</th><th>Period</th><th>WAC</th>
                                <th>Effective Start Date</th><th>Effective End Date</th><th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {wacHistoryData.map(item => (
                                <tr key={item.id}>
                                    <td>{item.brand}</td><td>{item.productId}</td><td>{item.period}</td><td>{item.wac}</td>
                                    <td>{item.effectiveStartDate}</td><td>{item.effectiveEndDate}</td>
                                    <td><Button variant="primary" size="sm" onClick={() => handleEditClick(item, "wac")}>Edit</Button></td>
                                </tr>
                            ))}
                            {addingNewWac && (
                                <tr>
                                    <td><Form.Control size="sm" name="brand" value={newWacRow.brand} onChange={handleNewWacChange} /></td>
                                    <td><Form.Control size="sm" name="productId" value={newWacRow.productId} onChange={handleNewWacChange} /></td>
                                    <td><Form.Control size="sm" name="period" value={newWacRow.period} onChange={handleNewWacChange} /></td>
                                    <td><Form.Control size="sm" type="number" name="wac" value={newWacRow.wac} onChange={handleNewWacChange} /></td>
                                    <td><Form.Control size="sm" type="date" name="effectiveStartDate" value={newWacRow.effectiveStartDate} onChange={handleNewWacChange} /></td>
                                    <td><Form.Control size="sm" type="date" name="effectiveEndDate" value={newWacRow.effectiveEndDate} onChange={handleNewWacChange} /></td>
                                    <td>
                                        <Button variant="success" size="sm" onClick={handleNewWacSave}
                                            disabled={!newWacRow.brand || !newWacRow.productId || !newWacRow.period || !newWacRow.wac || !newWacRow.effectiveStartDate || !newWacRow.effectiveEndDate}>
                                            Save
                                        </Button>
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </Table>
                </Col>
            </Row>

            {/* Demand Units Table */}
            <Row className="align-items-center mb-2">
                <Col><h5>Demand Units Table</h5></Col>
                <Col className="text-end">
                    <Button variant="success" size="sm" onClick={() => setAddingNewDemand(true)}>Add</Button>
                </Col>
            </Row>
            <Row>
                <Col>
                    <Table striped bordered responsive className="text-center">
                        <thead>
                            <tr>
                                <th>Brand</th><th>Period</th><th>Product ID</th><th>Demand Unit Value</th>
                                <th>Effective Start Date</th><th>Effective End Date</th><th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {demandUnitData.map(item => (
                                <tr key={item.id}>
                                    <td>{item.brand}</td><td>{item.period}</td><td>{item.productId}</td><td>{item.demandUnitValue}</td>
                                    <td>{item.effectiveStartDate}</td><td>{item.effectiveEndDate}</td>
                                    <td><Button variant="primary" size="sm" onClick={() => handleEditClick(item, "demand")}>Edit</Button></td>
                                </tr>
                            ))}
                            {addingNewDemand && (
                                <tr>
                                    <td><Form.Control size="sm" name="brand" value={newDemandRow.brand} onChange={handleNewDemandChange} /></td>
                                    <td><Form.Control size="sm" name="period" value={newDemandRow.period} onChange={handleNewDemandChange} /></td>
                                    <td><Form.Control size="sm" name="productId" value={newDemandRow.productId} onChange={handleNewDemandChange} /></td>
                                    <td><Form.Control size="sm" type="number" name="demandUnitValue" value={newDemandRow.demandUnitValue} onChange={handleNewDemandChange} /></td>
                                    <td><Form.Control size="sm" type="date" name="effectiveStartDate" value={newDemandRow.effectiveStartDate} onChange={handleNewDemandChange} /></td>
                                    <td><Form.Control size="sm" type="date" name="effectiveEndDate" value={newDemandRow.effectiveEndDate} onChange={handleNewDemandChange} /></td>
                                    <td>
                                        <Button variant="success" size="sm" onClick={handleNewDemandSave}
                                            disabled={!newDemandRow.brand || !newDemandRow.productId || !newDemandRow.period || !newDemandRow.demandUnitValue || !newDemandRow.effectiveStartDate || !newDemandRow.effectiveEndDate}>
                                            Save
                                        </Button>
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </Table>
                </Col>
            </Row>

            {/* Modal for Editing */}
            <Modal show={showModal} onHide={handleCloseModal}>
                <Modal.Header closeButton>
                    <Modal.Title>Edit {editType === "wac" ? "WAC Entry" : "Demand Unit Entry"}</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    {selectedRow && (
                        <Form>
                            <Form.Group className="mb-3">
                                <Form.Label>Brand</Form.Label>
                                <Form.Control type="text" name="brand" value={selectedRow.brand} onChange={handleChange} />
                            </Form.Group>
                            <Form.Group className="mb-3">
                                <Form.Label>Product ID</Form.Label>
                                <Form.Control type="text" name="productId" value={selectedRow.productId} onChange={handleChange} />
                            </Form.Group>
                            <Form.Group className="mb-3">
                                <Form.Label>Period</Form.Label>
                                <Form.Control type="text" name="period" value={selectedRow.period} onChange={handleChange} />
                            </Form.Group>
                            {editType === "wac" ? (
                                <Form.Group className="mb-3">
                                    <Form.Label>WAC</Form.Label>
                                    <Form.Control type="number" name="wac" value={selectedRow.wac} onChange={handleChange} />
                                </Form.Group>
                            ) : (
                                <Form.Group className="mb-3">
                                    <Form.Label>Demand Unit Value</Form.Label>
                                    <Form.Control type="number" name="demandUnitValue" value={selectedRow.demandUnitValue} onChange={handleChange} />
                                </Form.Group>
                            )}
                            <Form.Group className="mb-3">
                                <Form.Label>Effective Start Date</Form.Label>
                                <Form.Control type="date" name="effectiveStartDate" value={selectedRow.effectiveStartDate} onChange={handleChange} />
                            </Form.Group>
                            <Form.Group className="mb-3">
                                <Form.Label>Effective End Date</Form.Label>
                                <Form.Control type="date" name="effectiveEndDate" value={selectedRow.effectiveEndDate} onChange={handleChange} />
                            </Form.Group>
                        </Form>
                    )}
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleCloseModal}>Cancel</Button>
                    <Button variant="success" onClick={handleSave}>Save Changes</Button>
                </Modal.Footer>
            </Modal>
        </Container>
    );
}

export default Admin;
