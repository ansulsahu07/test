import React from 'react';
import { Table, Button } from 'react-bootstrap';
import { useNavigate } from "react-router-dom";
import { DEAL_ROUTES } from "../constants/routes";

const History = () => {
  const navigate = useNavigate();
  

// const TdcellStyle = {
//   width: '160px',
//   textAlign: 'center',
//   verticalAlign: 'middle',
//   wordWrap: 'break-word',
// };
// const valuecellStyle = {
//   width: '160px',
//   textAlign: 'center',
//   verticalAlign: 'middle',
//   wordWrap: 'break-word',
// };

  const mockData = {
    ajovyPFS: [
      { quarter: "1Q2026", WAC: 792.91, URA: 615.85, URAPercent: "77.7%", ModifiedDate: "10/7/2025" },
      { quarter: "2Q2026", WAC: 792.91, URA: 602.76, URAPercent: "76.0%", ModifiedDate: "10/7/2025" },
      { quarter: "3Q2026", WAC: 792.91, URA: 599.79, URAPercent: "75.6%", ModifiedDate: "10/7/2025" },
      { quarter: "4Q2026", WAC: 798.00, URA: 598.20, URAPercent: "75.4%", ModifiedDate: "10/7/2025" },
      { quarter: "1Q2027", WAC: 831.76, URA: 663.68, URAPercent: "79.8%", ModifiedDate: "10/7/2025" },
      { quarter: "2Q2027", WAC: 831.76, URA: 651.00, URAPercent: "78.3%", ModifiedDate: "10/7/2025" },
      { quarter: "3Q2027", WAC: 831.76, URA: 648.72, URAPercent: "78.0%", ModifiedDate: "10/7/2025" },
      { quarter: "1Q2028", WAC: 872.52, URA: 647.47, URAPercent: "74.2%", ModifiedDate: "10/7/2025" },
    ],
    ajovyAutoInj1: [
      { quarter: "1Q2026", WAC: 792.91, URA: 615.85, URAPercent: "77.7%", ModifiedDate: "10/7/2025" },
      { quarter: "2Q2026", WAC: 792.91, URA: 602.76, URAPercent: "76.0%", ModifiedDate: "10/7/2025" },
      { quarter: "3Q2026", WAC: 792.91, URA: 599.79, URAPercent: "75.6%", ModifiedDate: "10/7/2025" },
      { quarter: "4Q2026", WAC: 798.00, URA: 598.20, URAPercent: "75.4%", ModifiedDate: "10/7/2025" },
      { quarter: "1Q2027", WAC: 831.76, URA: 663.68, URAPercent: "79.8%", ModifiedDate: "10/7/2025" },
      { quarter: "2Q2027", WAC: 831.76, URA: 651.00, URAPercent: "78.3%", ModifiedDate: "10/7/2025" },
      { quarter: "3Q2027", WAC: 831.76, URA: 648.72, URAPercent: "78.0%", ModifiedDate: "10/7/2025" },
      { quarter: "1Q2028", WAC: 872.52, URA: 647.47, URAPercent: "74.2%", ModifiedDate: "10/7/2025" },
    ],
    ajovyAutoInj2: [
      { quarter: "1Q2026", WAC: 792.91, URA: 615.85, URAPercent: "77.7%", ModifiedDate: "10/7/2025" },
      { quarter: "2Q2026", WAC: 792.91, URA: 602.76, URAPercent: "76.0%", ModifiedDate: "10/7/2025" },
      { quarter: "3Q2026", WAC: 792.91, URA: 599.79, URAPercent: "75.6%", ModifiedDate: "10/7/2025" },
      { quarter: "4Q2026", WAC: 798.00, URA: 598.20, URAPercent: "75.4%", ModifiedDate: "10/7/2025" },
      { quarter: "1Q2027", WAC: 831.76, URA: 663.68, URAPercent: "79.8%", ModifiedDate: "10/7/2025" },
      { quarter: "4Q2026", WAC: 798.00, URA: 598.20, URAPercent: "75.4%", ModifiedDate: "10/7/2025" },
      { quarter: "1Q2027", WAC: 831.76, URA: 663.68, URAPercent: "79.8%", ModifiedDate: "10/7/2025" },
      { quarter: "4Q2026", WAC: 798.00, URA: 598.20, URAPercent: "75.4%", ModifiedDate: "10/7/2025" },
      { quarter: "1Q2027", WAC: 831.76, URA: 663.68, URAPercent: "79.8%", ModifiedDate: "10/7/2025" },
      { quarter: "4Q2026", WAC: 798.00, URA: 598.20, URAPercent: "75.4%", ModifiedDate: "10/7/2025" },
      { quarter: "1Q2027", WAC: 831.76, URA: 663.68, URAPercent: "79.8%", ModifiedDate: "10/7/2025" },

    ]
  };

  const HistoryTable = ({ title, data }) => {
    const quarters = data.map(item => item.quarter);
    const WAC = data.map(item => item.WAC);
    const URA = data.map(item => item.URA);
    const URAPercent = data.map(item => item.URAPercent);
    const ModifiedDate = data.map(item => item.ModifiedDate);

    return (
      <>
        {/* <h5 className="mt-4">{title}</h5> */}
        <Table striped bordered
          responsive hover size="md" >
          <thead>
            <tr>
              <th>{title}</th>
              {quarters.map((q, idx) => <th key={idx}>{q}</th>)}
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>WAC ($)</td>
              {WAC.map((val, idx) => <td key={idx}>{val}</td>)}
            </tr>
            <tr>
              <td>URA ($)</td>
              {URA.map((val, idx) => <td key={idx}>{val}</td>)}
            </tr>
            <tr>
              <td>URA % of WAC</td>
              {URAPercent.map((val, idx) => <td key={idx}>{val}</td>)}
            </tr>
            <tr>
              <td>Modified Date</td>
              {ModifiedDate.map((val, idx) => <td key={idx}>{val}</td>)}
            </tr>
          </tbody>
        </Table>
      </>
    );
  };

  return (
    <div className="container">
      <Button variant="outline-danger" xs={5}>Close</Button>
      <HistoryTable title="Ajovy PFS" data={mockData.ajovyPFS} />
      <HistoryTable title="Ajovy Auto Inj 1" data={mockData.ajovyAutoInj1} />
      <HistoryTable title="Ajovy Auto Inj 2" data={mockData.ajovyAutoInj2} />
      <Button
        className="vi-btn-solid-magenta vi-btn-solid"
        onClick={() => navigate(DEAL_ROUTES.HOME.PATH)}
      >
        BACK
      </Button>
    </div>
  );
};

export default History;
