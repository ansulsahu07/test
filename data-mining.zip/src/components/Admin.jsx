
import React, { useState } from "react";
import { Button, Col, Container, Form, Modal, Row, Table } from "react-bootstrap";
const today = new Date().toISOString().split("T")[0];

function Admin() {
  const [wacHistoryData, setWacHistoryData] = useState([
    { id: 12, label: "WAC History" },
    { id: 1, brand: "AJOVY", productId: 1234, period: 101, wac: 120.5, effectiveStartDate: "2025-01-01", effectiveEndDate: "2025-03-31" },
    { id: 2, brand: "AJOVY", productId: 1234, period: 107, wac: 8.5, effectiveStartDate: "2025-01-01", effectiveEndDate: "2025-03-31" }
  ]);

  const [demandUnitData, setDemandUnitData] = useState([
    { id: 13, label: "Demand Units" },
    { id: 1, brand: "AJOVY", productId: 5678, period: 202, demandUnitValue: 1500, effectiveStartDate: "2025-04-01", effectiveEndDate: "2025-06-30" }
  ]);

  const [cogsData, setCogsData] = useState([
    { id: 14, label: "COGS" },
    { id: 1, brand: "AJOVY", productId: 91011, period: 303, cogsUnitValue: 1000, effectiveStartDate: "2025-07-01", effectiveEndDate: "2025-09-30" }
  ]);
  const [operatingCostsData, setOperatingCostsData] = useState([
    { id: 15, label: "Operating Costs" },
    {
      id: 1,
      brand: "AJOVY",
      period: 101,
      operatingCostsType: "Manufacturing",
      operatingCostValue: 101143,
      effectiveStartDate: "2025-01-01",
      effectiveEndDate: "2025-03-31"
    }
  ]);


  const dropdownOptions = [
    {
      brand: [
        "AJOVY",
        "AUSTEDO",
        "CINQAIR",
        "COPAXONE 20",
        "COPAXONE 40",
      ],
      productId: [1234, 5678, 91011],
      period: [101, 202, 303]
    }
  ];

  // const tableSources = [
  //   { data: wacHistoryData, type: "wac", setter: setWacHistoryData },
  //   { data: demandUnitData, type: "demand", setter: setDemandUnitData },
  //   { data: cogsData, type: "cogs", setter: setCogsData }
  // ];
  const tableSources = [
    { data: wacHistoryData, type: "wac", setter: setWacHistoryData },
    { data: demandUnitData, type: "demand", setter: setDemandUnitData },
    { data: cogsData, type: "cogs", setter: setCogsData },
    { data: operatingCostsData, type: "operating", setter: setOperatingCostsData }
  ];


  const tableOptions = tableSources.map(source => ({
    id: source.data[0].id,
    label: source.data[0].label,
    type: source.type
  }));

  const [selectedTableId, setSelectedTableId] = useState(tableOptions[0].id);
  const [showModal, setShowModal] = useState(false);
  const [selectedRow, setSelectedRow] = useState(null);
  const [editType, setEditType] = useState("");
  // const [addCount, setAddCount] = useState(0);
  const [newRows, setNewRows] = useState([]);

  const handleEditClick = (item, type) => {
    setSelectedRow({ ...item });
    setEditType(type);
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setSelectedRow(null);
    setEditType("");
  };

  const handleSave = () => {
    const source = tableSources.find(s => s.type === editType);
    source.setter(prev => prev.map(row => row.id === selectedRow.id ? selectedRow : row));
    handleCloseModal();
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setSelectedRow(prev => ({
      ...prev,
      [name]: ["wac", "demandUnitValue", "cogsUnitValue",'operating'].includes(name) ? parseFloat(value) : value
    }));
  };

  const handleNewRowChange = (index, e) => {
    const { name, value } = e.target;
    setNewRows(prev => {
      const updated = [...prev];
      updated[index][name] = ["wac", "demandUnitValue", "cogsUnitValue"].includes(name) ? parseFloat(value) : value;
      return updated;
    });
  };

  const handleSaveNewRow = (index, type) => {
    const row = newRows[index];
    const source = tableSources.find(s => s.type === type);
    source.setter(prev => [...prev, { ...row, id: prev.length }]);
    setNewRows(prev => prev.filter((_, i) => i !== index));
  };

  return (
    <Container>
      <Row className="mb-3">
        <Col md={4}>
          <Form.Select
            value={selectedTableId}
            onChange={(e) => {
              setSelectedTableId(parseInt(e.target.value));
              // setAddCount(0);
              setNewRows([]);
            }}
          >
            {tableOptions.map(option => (
              <option key={option.id} value={option.id}>
                {option.label}
              </option>
            ))}
          </Form.Select>
        </Col>
      </Row>

      {tableSources.map(source => {
        const metadata = source.data[0];
        const rows = source.data.slice(1);
        if (metadata.id !== selectedTableId) return null;

        return (
          <div key={metadata.id}>
            <Row className="align-items-center mb-2">
              <Col><h5>{metadata.label} Table</h5></Col>
              <Col className="text-end">
                <Form.Select
                  size="sm"
                  style={{ width: "120px", display: "inline-block" }}
                  onChange={(e) => {
                    const count = parseInt(e.target.value);
                    // setAddCount(count);
                    const emptyRows = Array.from({ length: count }, (_, i) => ({
                      id: `new-${i}`,
                      brand: "", productId: "", period: "",
                      wac: "", demandUnitValue: "", cogsUnitValue: "",
                      effectiveStartDate: today, effectiveEndDate: ""
                    }));
                    setNewRows(emptyRows);
                  }}
                >
                  <option value="">Add Rows</option>
                  {Array.from({ length: 10 }, (_, i) => i + 1).map(num => (
                    <option key={num} value={num}>{num}</option>
                  ))}
                </Form.Select>
              </Col>
            </Row>

            <Table striped bordered responsive className="text-center">
              <thead>
                <tr>
                  <th>Brand</th>
                  {/* <th>Product ID</th> */}
                  {source.type !== "operating" && <th>Product ID</th>}

                  <th>Period</th>
                  {/* {source.type === "operating" && <th>Operating Costs Type</th>} */}
                  {source.type === "operating" && (
                    <>
                      <th>Operating Costs Type</th>
                      <th>Operating Costs value</th>
                    </>
                  )}
                  {source.type === "wac" && <th>WAC</th>}
                  {source.type === "demand" && <th>Demand Unit Value</th>}
                  {source.type === "cogs" && <th>COGS Units Value</th>}

                  {/* <th>{source.type === "wac" ? "WAC" : source.type === "demand" ? "Demand Unit Value" : source.type === "cogs" ? "COGS Unit Value" : "Operating Cost Value"}</th> */}


                  <th>Effective Start Date</th><th>Effective End Date</th><th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {rows.map(row => (
                  <tr key={row.id}>
                    <td>{row.brand}</td>
                    {/* {<td>{row.productId}</td>} */}
                    {source.type !== "operating" && <td>{row.productId}</td>}

                    <td>{row.period}</td>
                    {/* suri  */}

                    {/* {source.type === "operating" && <td>{row.operatingCostsType}</td>  <td>{row.operatingCostsType}</td>} */}
                    {source.type === "operating" && (
                      <>
                        <td>{row.operatingCostsType}</td>
                        <td>{row.operatingCostValue}</td>
                      </>
                    )}


                    {source.type === "wac" && <td>{row.wac}</td>}
                    {source.type === "demand" && <td>{row.demandUnitValue}</td>}
                    {source.type === "cogs" && <td>{row.cogsUnitValue}</td>}
                    <td>{row.effectiveStartDate}</td><td>{row.effectiveEndDate}</td>
                    <td><Button size="sm" onClick={() => handleEditClick(row, source.type)}>Edit</Button></td>
                  </tr>
                ))}
                {/* // suri */}


              {newRows.map((row, index) => (
  <tr key={row.id}>
    {/* Brand - always shown */}
    <td>
      <Form.Select size="sm" name="brand" value={row.brand} onChange={(e) => handleNewRowChange(index, e)}>
        <option value="">Select</option>
        {dropdownOptions[0].brand.map(opt => (
          <option key={opt} value={opt}>{opt}</option>
        ))}
      </Form.Select>
    </td>

    {/* Product ID - only for non-operating */}
    {source.type !== "operating" && (
      <td>
        <Form.Select size="sm" name="productId" value={row.productId} onChange={(e) => handleNewRowChange(index, e)}>
          <option value="">Select</option>
          {dropdownOptions[0].productId.map(opt => (
            <option key={opt} value={opt}>{opt}</option>
          ))}
        </Form.Select>
      </td>
    )}

    {/* Period - always shown */}
    <td>
      <Form.Select size="sm" name="period" value={row.period} onChange={(e) => handleNewRowChange(index, e)}>
        <option value="">Select</option>
        {dropdownOptions[0].period.map(opt => (
          <option key={opt} value={opt}>{opt}</option>
        ))}
      </Form.Select>
    </td>

    {/* Value fields based on type */}
    {source.type === "wac" && (
      <td>
        <Form.Control size="sm" type="number" name="wac" value={row.wac} onChange={(e) => handleNewRowChange(index, e)} />
      </td>
    )}
    {source.type === "demand" && (
      <td>
        <Form.Control size="sm" type="number" name="demandUnitValue" value={row.demandUnitValue} onChange={(e) => handleNewRowChange(index, e)} />
      </td>
    )}
    {source.type === "cogs" && (
      <td>
        <Form.Control size="sm" type="number" name="cogsUnitValue" value={row.cogsUnitValue} onChange={(e) => handleNewRowChange(index, e)} />
      </td>
    )}
    {source.type === "operating" && (
      <>
        <td>
          <Form.Control size="sm" type="text" name="operatingCostsType" value={row.operatingCostsType || ""} onChange={(e) => handleNewRowChange(index, e)} />
        </td>
        <td>
          <Form.Control size="sm" type="number" name="operatingCostValue" value={row.operatingCostValue || ""} onChange={(e) => handleNewRowChange(index, e)} />
        </td>
      </>
    )}

    {/* Dates - always shown */}
    <td>
      <Form.Control size="sm" type="date" name="effectiveStartDate" value={row.effectiveStartDate} onChange={(e) => handleNewRowChange(index, e)} />
    </td>
    <td>
      <Form.Control size="sm" type="date" name="effectiveEndDate" value={row.effectiveEndDate} onChange={(e) => handleNewRowChange(index, e)} />
    </td>

    {/* Save button with conditional validation */}
    <td>
      <Button
        variant="success"
        size="sm"
        onClick={() => handleSaveNewRow(index, source.type)}
        disabled={
          !row.brand ||
          (source.type !== "operating" && !row.productId) ||
          !row.period ||
          (source.type === "wac" && !row.wac) ||
          (source.type === "demand" && !row.demandUnitValue) ||
          (source.type === "cogs" && !row.cogsUnitValue) ||
          (source.type === "operating" && (!row.operatingCostsType || !row.operatingCostValue)) ||
          !row.effectiveStartDate ||
          !row.effectiveEndDate
        }
      >
        Save
      </Button>
    </td>
  </tr>
))}

              </tbody>
            </Table>
          </div>
        );
      })}

   <Modal show={showModal} onHide={handleCloseModal}>
  <Modal.Header closeButton>
    <Modal.Title>Edit Entry</Modal.Title>
  </Modal.Header>
  <Modal.Body>
    {selectedRow && (
      <Form>
        {/* Brand - always shown */}
        <Form.Group className="mb-3">
          <Form.Label>Brand</Form.Label>
          <Form.Control
            type="text"
            name="brand"
            value={selectedRow.brand}
            onChange={handleChange}
          />
        </Form.Group>

        {/* Product ID - shown only if not operating */}
        {editType !== "operating" && (
          <Form.Group className="mb-3">
            <Form.Label>Product ID</Form.Label>
            <Form.Control
              type="text"
              name="productId"
              value={selectedRow.productId}
              onChange={handleChange}
            />
          </Form.Group>
        )}

        {/* Period - always shown */}
        <Form.Group className="mb-3">
          <Form.Label>Period</Form.Label>
          <Form.Control
            type="text"
            name="period"
            value={selectedRow.period}
            onChange={handleChange}
          />
        </Form.Group>

        {/* Operating Costs fields */}
        {editType === "operating" && (
          <>
            <Form.Group className="mb-3">
              <Form.Label>Operating Costs Type</Form.Label>
              <Form.Control
                type="text"
                name="operatingCostsType"
                value={selectedRow.operatingCostsType || ""}
                onChange={handleChange}
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Operating Cost Value</Form.Label>
              <Form.Control
                type="number"
                name="operatingCostValue"
                value={selectedRow.operatingCostValue || ""}
                onChange={handleChange}
              />
            </Form.Group>
          </>
        )}

        {/* WAC */}
        {editType === "wac" && (
          <Form.Group className="mb-3">
            <Form.Label>WAC</Form.Label>
            <Form.Control
              type="number"
              name="wac"
              value={selectedRow.wac}
              onChange={handleChange}
            />
          </Form.Group>
        )}

        {/* Demand Unit */}
        {editType === "demand" && (
          <Form.Group className="mb-3">
            <Form.Label>Demand Unit Value</Form.Label>
            <Form.Control
              type="number"
              name="demandUnitValue"
              value={selectedRow.demandUnitValue}
              onChange={handleChange}
            />
          </Form.Group>
        )}

        {/* COGS */}
        {editType === "cogs" && (
          <Form.Group className="mb-3">
            <Form.Label>COGS Units Value</Form.Label>
            <Form.Control
              type="number"
              name="cogsUnitValue"
              value={selectedRow.cogsUnitValue}
              onChange={handleChange}
            />
          </Form.Group>
        )}

        {/* Dates - always shown */}
        <Form.Group className="mb-3">
          <Form.Label>Effective Start Date</Form.Label>
          <Form.Control
            type="date"
            name="effectiveStartDate"
            value={selectedRow.effectiveStartDate}
            onChange={handleChange}
          />
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label>Effective End Date</Form.Label>
          <Form.Control
            type="date"
            name="effectiveEndDate"
            value={selectedRow.effectiveEndDate}
            onChange={handleChange}
          />
        </Form.Group>
      </Form>
    )}
  </Modal.Body>
  <Modal.Footer>
    <Button variant="secondary" onClick={handleCloseModal}>Cancel</Button>
    <Button variant="success" onClick={handleSave}>Save Changes</Button>
  </Modal.Footer>
</Modal>

    </Container>
  );
}

export default Admin;
