import tevaLogo from "./assets/images/teva-logo.svg";
import "./App.css";
import { Container, Navbar } from "react-bootstrap";
import { Route, Routes } from "react-router-dom";
import { DEAL_ROUTES } from "./constants/routes";
import useScreenSize from "./hooks/useScreenSize";
import ClientAndBidInformation from "./components/ClientAndBidInformation";
import UtilizationAndMSData from "./components/UtilizationAndMSData";
import DealAnalysisModel from "./components/DealAnalysisModel";
import History from './components/History'

function App() {
  const isDesktop = useScreenSize();

  if (!isDesktop) {
    return (
      <Container className="d-flex justify-content-center">
        This app is only available on Desktop
      </Container>
    );
  }

  return (
    <Container fluid>
      <Navbar className="justify-content-center py-5">
        <Container className="d-flex justify-content-center">
          <img
            src={tevaLogo}
            className="d-inline-block align-top teva-logo"
            alt="Teva"
          />
        </Container>
      </Navbar>
      <Routes>
        <Route path={DEAL_ROUTES.HOME.PATH} element={<ClientAndBidInformation />} />
        <Route path={DEAL_ROUTES.UTILIZATIONANDMSDATA.PATH} element={<UtilizationAndMSData />} />
        <Route path={DEAL_ROUTES.DEAL_ANALYSIS_MODEL.PATH} element={<DealAnalysisModel />} />
        <Route path={DEAL_ROUTES.HISTORTY_MODEL.PATH} element={<History />} />
      </Routes>
    </Container>
  );
}

export default App;
