var FORMULAS = [
  { "field": "totalOptionsVsNmsProj", "formula": "totalOptionMarketShareProj - nmsProj" },
  { "field": "grossSales", "formula": "wac * optionTrxProj" },
  { "field": "guaranteedRebateDollar", "formula": "totalGrossSales * guaranteedRebateAdminPercent * 0.01" },
  { "field": "totalOperatingExpenses", "formula": "operatingCostsFixedDollar + operatingCostsVariableDollar" },
  { "field": "priceProtectionRebateDollar", "formula": "totalGrossSales * priceProtectionRebatePercent * 0.01" },
  { "field": "totalRebatePPDollar", "formula": "guaranteedRebateAdminDollar + adminFeeDollar + priceProtectionRebateDollar" },
  { "field": "purchaseDiscountDollar", "formula": "totalGrossSales * purchaseDiscountPercent * 0.01" },
  { "field": "iraDollar", "formula": "totalGrossSales * iraPercent * 0.01" },
  { "field": "netSales", "formula": "totalGrossSales - totalRebatePPDollar - purchaseDiscountDollar - iraDollar" },
  { "field": "totalRoyalties", "formula": "royaltiesPercent * 0.01 * netSales" },
  { "field": "totalGrossProfit", "formula": "netSales - totalCogs - totalRoyalties" },
  { "field": "operatingCostsFixedDollar", "formula": "totalGrossSales * operatingCostsFixedPercent * 0.01" },
  { "field": "operatingCostsVariableDollar", "formula": "totalGrossSales * operatingCostsVariablePercent * 0.01" },
  { "field": "totalGrossProfitLessOperatingCost", "formula": "totalGrossProfit - totalOperatingExpenses" },
  { "field": "adminFeeDollar", "formula": "totalGrossSales * adminFeePercent * 0.01" }
];