// formula-modal.js — shared modal for both screen1 and screen2
// Requires: formulas.js loaded before this file (provides FORMULAS global)
// Requires: formula-modal.html injected into the page (or call injectFormulaModal())

(function () {
  // ── Inject modal HTML into body if not already present ──────────────────────
  function injectFormulaModal() {
    if (document.getElementById("formulaOverlay")) return;
    const div = document.createElement("div");
    div.innerHTML = `
      <div id="formulaOverlay" style="display:none;position:fixed;inset:0;z-index:1000;background:rgba(0,0,0,0.45);align-items:center;justify-content:center;">
        <div style="background:#fff;border-radius:12px;box-shadow:0 8px 40px rgba(0,0,0,0.18);width:700px;max-width:95vw;max-height:85vh;display:flex;flex-direction:column;overflow:hidden;">
          <div style="display:flex;align-items:center;justify-content:space-between;padding:18px 24px 14px;border-bottom:1px solid #d0e0e8;">
            <span style="font-size:18px;font-weight:700;color:#005670;">Formula Table</span>
            <button id="closeFormulaBtn" style="background:none;border:none;cursor:pointer;font-size:22px;color:#777;line-height:1;" title="Close">&times;</button>
          </div>
          <div style="overflow-y:auto;">
            <table style="width:100%;border-collapse:collapse;font-size:13px;">
              <thead>
                <tr style="background:#f0f5f8;">
                  <th style="text-align:left;padding:10px 24px;color:#005670;font-weight:700;border-bottom:1px solid #d0e0e8;width:38%;">Field</th>
                  <th style="text-align:left;padding:10px 24px;color:#005670;font-weight:700;border-bottom:1px solid #d0e0e8;">Formula</th>
                </tr>
              </thead>
              <tbody id="formulaModalBody"></tbody>
            </table>
          </div>
        </div>
      </div>`;
    document.body.appendChild(div.firstElementChild);

    // close handlers
    document
      .getElementById("closeFormulaBtn")
      .addEventListener("click", closeFormulaModal);
    document
      .getElementById("formulaOverlay")
      .addEventListener("click", function (e) {
        if (e.target === this) closeFormulaModal();
      });
  }

  // ── Open ─────────────────────────────────────────────────────────────────────
  function openFormulaModal() {
    injectFormulaModal();
    const overlay = document.getElementById("formulaOverlay");
    const tbody = document.getElementById("formulaModalBody");
    overlay.style.display = "flex";

    if (typeof FORMULAS !== "undefined" && Array.isArray(FORMULAS)) {
      tbody.innerHTML = FORMULAS.map(function (r, i) {
        return (
          '<tr style="background:' +
          (i % 2 === 0 ? "#f7fafc" : "#fff") +
          '">' +
          '<td style="padding:9px 24px;color:#005670;border-bottom:1px solid #e8f0f4;text-align:left;">' +
          r.field +
          "</td>" +
          '<td style="padding:9px 24px;color:#333;border-bottom:1px solid #e8f0f4;text-align:left;">' +
          r.formula +
          "</td>" +
          "</tr>"
        );
      }).join("");
    } else {
      tbody.innerHTML =
        '<tr><td colspan="2" style="padding:16px 24px;color:#c0392b;">⚠ FORMULAS not defined. Ensure formulas.js is loaded before formula-modal.js.</td></tr>';
    }
  }

  // ── Close ────────────────────────────────────────────────────────────────────
  function closeFormulaModal() {
    const overlay = document.getElementById("formulaOverlay");
    if (overlay) overlay.style.display = "none";
  }

  // ── Expose globally ──────────────────────────────────────────────────────────
  window.openFormulaModal = openFormulaModal;
  window.closeFormulaModal = closeFormulaModal;

  // ── Auto-bind any element with data-formula-trigger attribute ────────────────
  document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll("[data-formula-trigger]").forEach(function (el) {
      el.addEventListener("click", openFormulaModal);
    });
  });
})();
